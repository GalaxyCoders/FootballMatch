package com.mqa.android.kade.model

data class MatchesFeed(val event: List<Results>)
