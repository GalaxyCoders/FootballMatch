package com.mqa.android.kade.model

data class SearchFeed(val event: List<Results>)