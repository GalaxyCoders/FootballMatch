package com.mqa.android.kade.model

data class DetailPlayer(val strPlayer: String,
                        val strDescriptionEN: String,
                        val strPosition: String,
                        val strFanart1: String,
                        val strHeight: String,
                        val strWeight: String
)