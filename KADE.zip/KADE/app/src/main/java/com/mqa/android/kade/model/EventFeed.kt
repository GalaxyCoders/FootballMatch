package com.mqa.android.kade.model

data class EventFeed(val events: List<DetailEvent>)