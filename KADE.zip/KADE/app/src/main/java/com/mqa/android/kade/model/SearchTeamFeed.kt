package com.mqa.android.kade.model

data class SearchTeamFeed(val teams: List<Team>)