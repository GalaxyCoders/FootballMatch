package com.mqa.android.kade.model


data class Players(val idPlayer: String,
                   val strPlayer: String,
                   val strPosition: String,
                   val strCutout: String,
                   val strFanart1: String)