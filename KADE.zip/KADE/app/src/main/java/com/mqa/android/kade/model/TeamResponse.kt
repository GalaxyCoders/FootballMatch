package com.mqa.android.kade.model

data class TeamResponse(
        val teams: MutableList<Team>)