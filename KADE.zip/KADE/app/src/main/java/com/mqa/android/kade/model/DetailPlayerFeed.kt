package com.mqa.android.kade.model

data class DetailPlayerFeed(val players: List<DetailPlayer>)