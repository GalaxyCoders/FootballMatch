package com.mqa.android.kade.model

data class Results(val strHomeTeam: String,
                   val strAwayTeam: String,
                   val intHomeScore: String,
                   val intAwayScore: String,
                   val idEvent: String,
                   val dateEvent: String,
                   val idHomeTeam: String,
                   val idAwayTeam: String)