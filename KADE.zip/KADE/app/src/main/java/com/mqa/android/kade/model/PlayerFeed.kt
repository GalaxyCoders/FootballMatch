package com.mqa.android.kade.model

data class PlayerFeed(val player: MutableList<Players>)