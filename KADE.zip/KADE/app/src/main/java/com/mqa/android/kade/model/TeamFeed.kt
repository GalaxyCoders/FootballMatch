package com.mqa.android.kade.model

data class TeamFeed(val events: List<Results>)
